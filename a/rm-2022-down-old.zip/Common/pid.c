//�Ժ�

#include "pid.h"
#include "common.h"

//component:Ҫ�أ����
//��ע������PIDʹ���������
void PID_Calc(struct PID_Regulator *pid)
{
	pid->err[0] = pid->ref - pid->fdb;//err[0]��ŵ���ref��fdb�Ĳ�ֵ�����
	
	if((pid->err[0] >= pid->jump_out) || (pid->err[0] < -pid->jump_out))
	{
		pid->componentKp = pid->kp * pid->err[0];
		VAL_LIMIT(pid->componentKp,-pid->componentKpMax,pid->componentKpMax)

		pid->componentKi+= pid->ki * pid->err[0];
		VAL_LIMIT(pid->componentKi,-pid->componentKiMax,pid->componentKiMax)
		if(pid->Reset_i == 1&& (pid->err[0] * pid->err[1] < 0))
		{
			pid->componentKi = 0;//����ki�õ���ֵ�ۼӣ��ﵽҪ����ڴ�����
		}
		
		pid->componentKd = pid->kd * ( pid->err[0] - pid->err[1] );
		VAL_LIMIT(pid->componentKd,-pid->componentKdMax,pid->componentKdMax)
		pid->componentoutput =pid->componentKp + pid->componentKi + pid->componentKd;
	}
	else
	{
	}
	pid->output = pid->componentoutput;
	VAL_LIMIT(pid->output,-pid->outputMax,pid->outputMax)
	
	pid->err[1] = pid->err[0];
}

void PID_Reset(PID_Regulator *pid)
{
	pid->ref 		= 0;
	pid->fdb		= 0;
	
	pid->err[0] = 0;
	pid->err[1]	= 0;

	pid->componentKp = 0;
	pid->componentKi = 0;
	pid->componentKd = 0;
	pid->componentoutput=0;
	pid->output			 = 0;
}

double yawKdPart_Array[5] = {0,0,0,0,0};
u8 yawKdPart_Index = 0;

//��̨ר��PID
//��ע:δʹ�ã�������һ�����ȡƽ��ֵ
void GimbalPID_Calc(PID_Regulator *pid)
{
	pid->err[0] = pid->ref - pid->fdb;
	
	if((pid->err[0] >= pid->jump_out) || (pid->err[0] < -pid->jump_out))
	{
		pid->componentKp = pid->kp * pid->err[0];
		VAL_LIMIT(pid->componentKp,-pid->componentKpMax,pid->componentKpMax)

		pid->componentKi+= pid->ki * pid->err[0];
		VAL_LIMIT(pid->componentKi,-pid->componentKiMax,pid->componentKiMax)
		if(pid->Reset_i == 1&& (pid->err[0] * pid->err[1] < 0))
		{
			pid->componentKi = 0;//����ki�õ���ֵ�ۼӣ��ﵽҪ����ڴ�����
		}
		
		yawKdPart_Array[yawKdPart_Index++] = pid->err[0] - pid->err[1];//ȡ������Ĳ�ֵ
		if(yawKdPart_Index>=5) yawKdPart_Index = 0;
		
		pid->componentKd = pid->kd * (yawKdPart_Array[0]+yawKdPart_Array[1]+yawKdPart_Array[2]+yawKdPart_Array[3]+yawKdPart_Array[4])/5;//ȡ������Ĳ�ֵȡƽ��
		VAL_LIMIT(pid->componentKd,-pid->componentKdMax,pid->componentKdMax)
		pid->componentoutput =pid->componentKp + pid->componentKi + pid->componentKd;
	}
	else
	{
	}
	pid->output = pid->componentoutput;
	VAL_LIMIT(pid->output,-pid->outputMax,pid->outputMax)
	
	pid->err[1] = pid->err[0];
}	

void GimbalPID_Reset(PID_Regulator *pid)
{
	pid->ref 		= 0;
	pid->fdb		= 0;
	
	pid->err[0] = 0;
	pid->err[1]	= 0;

	pid->componentKp = 0;
	pid->componentKi = 0;
	pid->componentKd = 0;
	pid->componentoutput=0;
	pid->output			 = 0;
}
