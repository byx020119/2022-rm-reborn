#ifndef CAN1_H
#define CAN1_H
#include "stm32f4xx.h"

void CAN1_Configuration(void);

#endif
