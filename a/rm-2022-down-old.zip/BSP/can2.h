#ifndef CAN2_H
#define CAN2_H
#include "stm32f4xx.h"

void CAN2_Configuration(void);

#endif
